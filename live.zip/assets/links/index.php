<html>
    <head>
        <title> Nothing Here</title>
        
        
            
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #0e0e0e;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            flex-direction: column;
        }
        
        </style>
    
    </head>
    <body>
        <center>
            <h1> চুরি করা মহাপাপ, আর চুরি কইরেন না !</h1>
        </center>
        
             <br>
         <script disable-devtool-auto src='https://cdn.jsdelivr.net/npm/disable-devtool@latest'></script>
         
    </body>
</html>